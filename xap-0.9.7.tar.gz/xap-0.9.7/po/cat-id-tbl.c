# SOME DESCRIPTIVE TITLE.
# Copyright (C) YEAR Free Software Foundation, Inc.
# FIRST AUTHOR <EMAIL@ADDRESS>, YEAR.
#
#, fuzzy
msgid ""
msgstr ""
"Project-Id-Version: PACKAGE VERSION\n"
"POT-Creation-Date: 1999-08-30 01:46+0200\n"
"PO-Revision-Date: YEAR-MO-DA HO:MI+ZONE\n"
"Last-Translator: FULL NAME <EMAIL@ADDRESS>\n"
"Language-Team: LANGUAGE <LL@li.org>\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=CHARSET\n"
"Content-Transfer-Encoding: ENCODING\n"

#: lib-src/gtk_dlg.c:168
msgid "Question"
msgstr ""

#: lib-src/gtk_dlg.c:172
msgid "Information"
msgstr ""

#: lib-src/gtk_dlg.c:176
msgid "Error"
msgstr ""

#: lib-src/gtk_dlg.c:180
msgid "Warning"
msgstr ""

#: lib-src/gtk_dlg.c:182
msgid "Dialog"
msgstr ""

#: lib-src/gtk_dlg.c:194 lib-src/gtk_exec.c:186
msgid "Ok"
msgstr ""

#: lib-src/gtk_dlg.c:196
msgid "Yes"
msgstr ""

#: lib-src/gtk_dlg.c:198
msgid "Continue"
msgstr ""

#: lib-src/gtk_dlg.c:211
msgid "Skip"
msgstr ""

#: lib-src/gtk_dlg.c:221 lib-src/gtk_exec.c:187
msgid "Cancel"
msgstr ""

#: lib-src/gtk_dlg.c:223
msgid "No"
msgstr ""

#: lib-src/gtk_dlg.c:232
msgid "All"
msgstr ""

#: lib-src/gtk_dlg.c:241
msgid "Close"
msgstr ""

#: lib-src/gtk_exec.c:171
msgid "Open with .."
msgstr ""

#: lib-src/gtk_exec.c:173 xap-src/xap_gui.c:820 xap-src/xap_gui.c:830
msgid "Execute .."
msgstr ""

#: lib-src/gtk_exec.c:220
msgid "Start in terminal"
msgstr ""

#: xap-src/xap_gui.c:121 xap-src/xap_gui.c:224
msgid "Can't execute"
msgstr ""

#: xap-src/xap_gui.c:604
msgid "Copy icon data from: "
msgstr ""

#: xap-src/xap_gui.c:616
msgid "New icon will be saved as"
msgstr ""

#: xap-src/xap_gui.c:625
msgid "Can't create icon from"
msgstr ""

#: xap-src/xap_gui.c:639
msgid "Override icon?"
msgstr ""

#: xap-src/xap_gui.c:679
msgid "New label: "
msgstr ""

#: xap-src/xap_gui.c:704
msgid "Link should not have spaces!"
msgstr ""

#: xap-src/xap_gui.c:770
msgid "Rename notebook-page to:"
msgstr ""

#: xap-src/xap_gui.c:816
msgid "Rename .."
msgstr ""

#: xap-src/xap_gui.c:817
msgid "Icon .."
msgstr ""

#: xap-src/xap_gui.c:818
msgid "Delete button"
msgstr ""

#: xap-src/xap_gui.c:822 xap-src/xap_gui.c:832
msgid "Quit"
msgstr ""

#: xap-src/xap_gui.c:827
msgid "New page .."
msgstr ""

#: xap-src/xap_gui.c:828
msgid "Rename page .."
msgstr ""
